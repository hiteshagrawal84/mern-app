const adminUserModel = require("../../models/adminuserModel")
const mongoose = require('mongoose')
const jwt = require("jsonwebtoken");

module.exports = {
  adminusers: async args => {
    try {
      
      
      
      const adminusersFetched = await adminUserModel.find()
      
      return adminusersFetched.map(adminuser => {
        return {
          ...adminuser._doc,
          _id: adminuser.id,
          createdAt: new Date(adminuser._doc.createdAt).toISOString(),
        }
      })
    } catch (error) {
      throw error
    }
  },

  createAdminUser: async args => {
    try {
        const {username, name,email,password,status} = args.adminUser  


      const adminuser = new adminUserModel({
        username, name,email,password,status
      })

      const token = jwt.sign(
        { user_id: adminuser._id, email },
        process.env.TOKEN_KEY,
        {
          expiresIn: "2h",
        }
      );

      adminuser.token = token;     
      const newAdminUser = await adminuser.save()         

      return { ...newAdminUser._doc, _id: newAdminUser.id }
    } catch (error) {
      throw error
    }
  },

  updateAdminUser: async args => {
    try {
       let id = args._id  
     
      const adminUserResp = await adminUserModel.findByIdAndUpdate(id, args.adminUser )  
       
      console.log(adminUserResp)
      return { ...adminUserResp._doc, _id: adminUserResp.id }
    } catch (error) {
      throw error
    }
  },


  deleteAdminUser: async args => {
    try {
       let id = args._id  
     
      const adminUserResp = await adminUserModel.findByIdAndRemove(id)  
        
      return { ...adminUserResp._doc, _id: adminUserResp.id }
    } catch (error) {
      throw error
    }
  },

}