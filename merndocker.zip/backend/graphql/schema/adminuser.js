const {buildSchema} = require("graphql")

module.exports = buildSchema (`

type AdminUser {
  _id: ID!
  username: String!
  name: String!
  email: String!
  password: String!
  status: Boolean!
  token: String
}

 input AdminUserInput {
    username: String!
    name: String!
    email: String!
    password: String!
    status: Boolean!    
 }

 type Query {
    adminusers:[AdminUser!]
  }

  type Mutation {
    createAdminUser(adminUser:AdminUserInput): AdminUser,
    updateAdminUser(_id: ID!, adminUser:AdminUserInput): AdminUser,
    deleteAdminUser(_id:ID!): AdminUser
  }
 

  schema {
    query: Query
    mutation: Mutation
  }

`)