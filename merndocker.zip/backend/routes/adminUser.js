const express = require('express')
var cors = require('cors')

const {
  getAdminUser, 
  getAdminUsers,
  createAdminUser,
  deleteAdminUser,
  updateAdminUser
  
} = require('../controllers/adminUserController')

const router = express.Router()

var corsOptions = {
  origin: 'http://example.com',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}


 // GET all workouts
router.get('/', getAdminUsers)

// GET a single workout
router.get('/:id', getAdminUser)

// POST a new workout
router.post('/', createAdminUser)

router.delete('/:id', deleteAdminUser)

router.patch('/:id', updateAdminUser)
 

module.exports = router