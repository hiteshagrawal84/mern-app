const express = require('express')
var cors = require('cors')

const {
  getBrokers, 
  getBroker,
  createBroker,
  deleteBroker,
  updateBroker
  
} = require('../controllers/brokerController')

const router = express.Router()

 
 // GET all workouts
router.get('/', getBrokers)

// GET a single workout
router.get('/:id', getBroker)

// POST a new workout
router.post('/', createBroker)

router.delete('/:id', deleteBroker)

router.patch('/:id', updateBroker)
 

module.exports = router