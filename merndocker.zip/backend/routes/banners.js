const express = require('express')

const auth = require('../middleware/auth');

const {
  getBanner, 
  getBanners,
  createBanner,
  deleteBanner,
  updateBanner
  
} = require('../controllers/bannersController')

var app = express();

app.use(function(req, res, next){
    console.log("A new request received at " + Date.now());
     
    next();
 });


const router = express.Router()

 // GET all workouts
router.get('/',auth, getBanners)

// GET a single workout
router.get('/:id', getBanner)

// POST a new workout
router.post('/', createBanner)

router.delete('/:id', deleteBanner)

router.patch('/:id', updateBanner)
 

module.exports = router