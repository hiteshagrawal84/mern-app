const express = require('express')
var cors = require('cors')

const {
  getCities, 
  getCity,
  createCity,
  deleteCity,
  updateCity
  
} = require('../controllers/cityController')

const router = express.Router()

 
 // GET all workouts
router.get('/', getCities)

// GET a single workout
router.get('/:id',   getCity,)

// POST a new workout
router.post('/', createCity)

router.delete('/:id', deleteCity)

router.patch('/:id', updateCity)
 

module.exports = router