const express = require('express')
var cors = require('cors')

const {
  getCountries, 
  getCountry,
  createCountry,
  deleteCountry,
  updateCountry
  
} = require('../controllers/countryController')

const router = express.Router()

 
 // GET all workouts
router.get('/', getCountries)

// GET a single workout
router.get('/:id',   getCountry,)

// POST a new workout
router.post('/', createCountry)

router.delete('/:id', deleteCountry)

router.patch('/:id', updateCountry)
 

module.exports = router