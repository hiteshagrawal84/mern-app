const express = require('express')
var cors = require('cors')

const {
  getHomes, 
  getHome,
  createHome,
  deleteHome,
  updateHome
  
} = require('../controllers/homeController')

const router = express.Router()

 
 // GET all workouts
router.get('/', getHomes)

// GET a single workout
router.get('/:id',   getHome,)

// POST a new workout
router.post('/', createHome)

router.delete('/:id', deleteHome)

router.patch('/:id', updateHome)
 

module.exports = router