const express = require('express')
var cors = require('cors')

const {
  getAreas, 
  getArea,
  createArea,
  deleteArea,
  updateArea
  
} = require('../controllers/areaController')

const router = express.Router()

 
 // GET all workouts
router.get('/', getAreas)

// GET a single workout
router.get('/:id',   getArea,)

// POST a new workout
router.post('/', createArea)

router.delete('/:id', deleteArea)

router.patch('/:id', updateArea)
 

module.exports = router