const adminUserModel = require('../models/adminuserModel')
const mongoose = require('mongoose')
const jwt = require("jsonwebtoken");

 
// get all workouts
const getAdminUsers = async (req, res) => {

  var host = req.get('origin');
  console.log(host)

  const { id } = req.params
  const adminUsers = await adminUserModel.find({},{username:1}).sort({createdAt: -1})
  console.log("dfdfd");
  res.status(200).json(adminUsers)
}


// get a single workout
const getAdminUser = async (req, res) => {

console.log("Hello");
 
 
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No User Found'})
  }
   

  const adminUser = await adminUserModel.findById(id)

  if (!adminUser) {
    return res.status(404).json({error: 'No such Admin'})
  }

  res.status(200).json(adminUser)
}

const deleteAdminUser = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No User Found'})
  }


  const adminUser = await adminUserModel.findOneAndDelete({_id: id})

   if (!adminUser) {
    return res.status(404).json({error: 'No such Admin'})
  }


  res.status(200).json({success: "Record Deleted Successfully"})
}


// create a new workout
const createAdminUser = async (req, res) => {
  const {username, name,email,password,status} = req.body

  let emptyFields = []  

   
  // add to the database
  try {
    const adminUser = await adminUserModel.create({ username, name,email,password,status})

    const token = jwt.sign(
      { user_id: adminUser._id,  email},
      process.env.TOKEN_KEY,
      {
        expiresIn: "24h",
      }
    );

    adminUser.token = token;    

    res.status(200).json(adminUser)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateAdminUser = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No User Found'})
  }


  const {username, name,email,password,status} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const adminUser = await adminUserModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!adminUser) {
      return res.status(404).json({error: 'No such Admin'})
      } 
    
    res.status(200).json(adminUser)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}


 

module.exports = {
  getAdminUser,
  getAdminUsers,
  createAdminUser,
  deleteAdminUser,
  updateAdminUser
}