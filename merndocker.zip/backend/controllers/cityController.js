const cityModel = require('../models/cityModel')
const mongoose = require('mongoose')
 

 
// get all workouts
const getCities = async (req, res) => {

  

  const { id } = req.params
  const cities = await cityModel.find({}).sort({createdAt: -1})
   
  res.status(200).json(cities)
}


// get a single workout
const getCity = async (req, res) => {
 
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No city Found'})
  }
   

  const city = await cityModel.findById(id)

  if (!city) {
    return res.status(404).json({error: 'No such city'})
  }

  res.status(200).json(city)
}

const deleteCity = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No city Found'})
  }


  const city = await cityModel.findOneAndDelete({_id: id})

   if (!city) {
    return res.status(404).json({error: 'No such city'})
  }

  res.status(200).json({success: "city Deleted Successfully"})
}


// create a new workout
const createCity = async (req, res) => {
  const {city_name,country_id} = req.body

  let emptyFields = []  

   
  // add to the database
  try {
    const city = await cityModel.create({ city_name,country_id})
 
    res.status(200).json(city)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateCity = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No city Found'})
  }


  const {city_name,country_id} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const city = await cityModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!city) {
      return res.status(404).json({error: 'No such city'})
      } 
    
    res.status(200).json(city)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

module.exports = {
  getCity,
  getCities,
  createCity,
  deleteCity,
  updateCity
}