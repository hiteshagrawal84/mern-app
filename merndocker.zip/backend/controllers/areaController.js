const areaModel = require('../models/areaModel')
const mongoose = require('mongoose')
 

 
// get all workouts
const getAreas = async (req, res) => {

  

  const { id } = req.params
  const areas = await areaModel.find({}).sort({createdAt: -1})
   
  res.status(200).json(areas)
}


// get a single workout
const getArea = async (req, res) => {
 
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No area Found'})
  }
   

  const area = await areaModel.findById(id)

  if (!area) {
    return res.status(404).json({error: 'No such area'})
  }

  res.status(200).json(area)
}

const deleteArea = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No area Found'})
  }


  const area = await areaModel.findOneAndDelete({_id: id})

   if (!area) {
    return res.status(404).json({error: 'No such area'})
  }

  res.status(200).json({success: "area Deleted Successfully"})
}


// create a new workout
const createArea = async (req, res) => {
  const {area_name,city_id} = req.body

  let emptyFields = []  

   
  // add to the database
  try {
    const area = await areaModel.create({ area_name,city_id})
 
    res.status(200).json(area)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateArea = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No area Found'})
  }


  const {area_name,city_id} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const area = await areaModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!area) {
      return res.status(404).json({error: 'No such area'})
      } 
    
    res.status(200).json(area)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

module.exports = {
  getArea,
  getAreas,
  createArea,
  deleteArea,
  updateArea
}