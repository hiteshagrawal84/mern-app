const brokerModel = require('../models/brokersModel')
const mongoose = require('mongoose')
const jwt = require("jsonwebtoken");

 
// get all workouts
const getBrokers = async (req, res) => {

  var host = req.get('origin');   

  const { id } = req.params
  const brokers = await brokerModel.find({}).sort({createdAt: -1})
   
  res.status(200).json(brokers)
}


// get a single workout
const getBroker = async (req, res) => {
 
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Broker Found'})
  }
   

  const broker = await brokerModel.findById(id)

  if (!broker) {
    return res.status(404).json({error: 'No such Broker'})
  }

  res.status(200).json(adminUser)
}

const deleteBroker = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Broker Found'})
  }


  const broker = await brokerModel.findOneAndDelete({_id: id})

   if (!broker) {
    return res.status(404).json({error: 'No such broker'})
  }

  res.status(200).json({success: "Broker Deleted Successfully"})
}


// create a new workout
const createBroker = async (req, res) => {
  const {username, name,email,phone,password,status} = req.body

  let emptyFields = []  

   
  // add to the database
  try {
    const broker = await brokerModel.create({ username, name,email,phone,password,status})

    const token = jwt.sign(
      { user_id: broker._id,  email},
      process.env.TOKEN_KEY,
      {
        expiresIn: "24h",
      }
    );

    broker.token = token;    

    res.status(200).json(broker)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateBroker = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Broker Found'})
  }


  const {username, name,email,phone,password,status} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const broker = await brokerModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!broker) {
      return res.status(404).json({error: 'No such Broker'})
      } 
    
    res.status(200).json(broker)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}


 

module.exports = {
  getBroker,
  getBrokers,
  createBroker,
  deleteBroker,
  updateBroker
}