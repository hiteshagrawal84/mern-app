const homeModel = require('../models/homeModel')
const mongoose = require('mongoose')
 

 
// get all workouts
const getHomes = async (req, res) => {

  

  const { id } = req.params
  const homes = await homeModel.find({}).sort({createdAt: -1})
   
  res.status(200).json(homes)
}


// get a single workout
const getHome = async (req, res) => {
 
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Home Found'})
  }
   

  const home = await homeModel.findById(id)

  if (!home) {
    return res.status(404).json({error: 'No such Home'})
  }

  res.status(200).json(home)
}

const deleteHome = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Home Found'})
  }


  const home = await homeModel.findOneAndDelete({_id: id})

   if (!home) {
    return res.status(404).json({error: 'No such home'})
  }

  res.status(200).json({success: "home Deleted Successfully"})
}


// create a new workout
const createHome = async (req, res) => {
  const {broker_id, area,city,country,flat_no,building_name,video,sale_rent} = req.body

  let emptyFields = []  

   
  // add to the database
  try {
    const home = await homeModel.create({ broker_id, area,city,country,flat_no,building_name,video,sale_rent})
 
    res.status(200).json(home)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateHome = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Home Found'})
  }


  const {broker_id, area,city,country,flat_no,building_name,video,sale_rent} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const home = await homeModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!home) {
      return res.status(404).json({error: 'No such home'})
      } 
    
    res.status(200).json(broker)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}


 

module.exports = {
  getHome,
  getHomes,
  createHome,
  deleteHome,
  updateHome
}