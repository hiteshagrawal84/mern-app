const bannerModel = require('../models/bannersModel')
const mongoose = require('mongoose')

 
// get all workouts
const getBanners = async (req, res) => {
  const banners = await bannerModel.find({}).sort({banner_position: 1})
 
  res.status(200).json(banners)
}


// get a single workout
const getBanner = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Banner Found'})
  }
   
  const banner = await bannerModel.findById(id)

  if (!banner) {
    return res.status(404).json({error: 'No such Banner'})
  }

  res.status(200).json(banner)
}

const deleteBanner = async (req, res) => {
  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Banner Found'})
  }


  const banner = await bannerModel.findOneAndDelete({_id: id})

   if (!banner) {
    return res.status(404).json({error: 'No such Banner'})
  }


  res.status(200).json({success: "Banner Deleted Successfully"})
}


// create a new workout
const createBanner = async (req, res) => {
  const {banner_image,banner_position} = req.body

  let emptyFields = []    

  // add to the database
  try {
    const banner = await bannerModel.create({ banner_image, banner_position})
    res.status(200).json(banner)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}

const updateBanner = async (req, res) => {

  const { id } = req.params
   
  if(!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({error:'No Banner Found'})
  }


  const {banner_image,banner_position} = req.body

  let emptyFields = []  
  

  // add to the database
  try {
    
    const banner = await bannerModel.findOneAndUpdate({_id: id}, {
      ...req.body
    })

    if (!banner) {
      return res.status(404).json({error: 'No such Banner'})
      } 
    
    res.status(200).json(banner)
  } catch (error) {
    res.status(400).json({ error: error.message })
  }
}


 

module.exports = {
    getBanner,
    getBanners,
    createBanner,
  deleteBanner,
  updateBanner
}