require('dotenv').config()
var express = require('express');
var cors = require('cors')
const mongoose = require('mongoose')
const adminUserRoutes = require('./routes/adminUser')
const brokerRoutes = require('./routes/broker')
const homeRoutes = require('./routes/home')
const cityRoutes = require('./routes/city')
const countryRoutes = require('./routes/country')
const areaRoutes = require('./routes/area')
 
var app = express(); 

app.use(express.json())

app.use('/rest/v1/api/adminusers', adminUserRoutes)
app.use('/rest/v1/api/broker', brokerRoutes)
app.use('/rest/v1/api/home', homeRoutes)
app.use('/rest/v1/api/country', countryRoutes)
app.use('/rest/v1/api/city', cityRoutes)
app.use('/rest/v1/api/area', areaRoutes)
 
console.log('Running  server at http://localhost:4000');

app.use(express.static('public')); 
app.use('/images', express.static('images'));

// connect to db
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('connected to database')
    // listen to port
    app.listen(process.env.NODE_DOCKER_PORT, () => {
      console.log('listening for requests on port', process.env.NODE_DOCKER_PORT)
    })
  })
  .catch((err) => {
    console.log(err)
  }) 