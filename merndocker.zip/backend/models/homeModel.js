const mongoose = require('mongoose')

const Schema = mongoose.Schema

const homeSchema = new Schema({
  broker_id: {
    type: Object,
    required: true,
    index:true     
  },
  area: {
    type: String,
    required: true
  },  
  city: {
    type: String,        
    required: true
  },  
  country: {
    type: String,
    unique: true,     
    required: true
  },
  flat_no: {
    type: String,
    required: true
  },
  building_name: {
    type: String,
    required: true
  }, 
  video: {
    type: String,
    required: true
  }, 
  sale_rent: {
    type: Number,
    required: true
  }, 
  status: {
    type: Boolean,
    required: true,
    default:false
  },   
}, { timestamps: true })
 
 
module.exports = mongoose.model('homes', homeSchema)

