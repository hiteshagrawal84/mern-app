const mongoose = require('mongoose')

const Schema = mongoose.Schema

const areaSchema = new Schema({
  area_name: {
    type: String,
    required: true      
  },  
  city_id: {
    type: Object,
    required: true      
  }  
}, { timestamps: true })
 
 
module.exports = mongoose.model('area', areaSchema)