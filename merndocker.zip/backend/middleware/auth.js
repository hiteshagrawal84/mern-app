const express = require('express')
const jwt = require('jsonwebtoken');
require('dotenv').config()
const mongoose = require('mongoose')
const adminUserModel = require('../models/adminuserModel')

module.exports = async (req, res, next)  => {
  try { 

    const token = req.headers.authorization.split(' ')[1];
     
    const decodedToken = jwt.verify(token, process.env.TOKEN_KEY);
     
    const userId = decodedToken.user_id;   

     
      if(!mongoose.Types.ObjectId.isValid(userId)) {
        throw "Authorization Failed";
      }

      const adminUser = await adminUserModel.findById(userId)
      
      if (!adminUser ) {
        throw "Authorization Failed";
      }

      next();

    }catch(err) {        
      res.status(401).json({
        error: err
      })
    } 
  }
 