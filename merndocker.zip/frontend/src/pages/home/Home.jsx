import React, { Component } from 'react';
import "./home.css";

class Home extends Component {
    render() {
        return (
            <div className="home">
             home
          </div>
        );
    }
}

export default Home;