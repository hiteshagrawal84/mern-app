
import React, { Component} from 'react';

import './AdminUsersList.css'
import { userRows } from "../../dummyData";
import { DataGrid } from "@material-ui/data-grid";
import { DeleteOutline } from "@material-ui/icons";
import { Link } from "react-router-dom";
import axios from 'axios';

class AdminUsers extends Component {
    
    constructor()
    {
        super()
           
        this.state = {
            userRows : []
        }
    }

    componentDidMount()
    {
        this.fetchAdminUsers()
    }

    fetchAdminUsers()
    {
        fetch(process.env.REACT_APP_API_END_POINT+"adminusers")
      .then((data) => data.json())
      .then((data) => this.setState({userRows:data}))    
    }

    handleDelete(id) {
        alert(id);
    }

    setPageSize(page)
    {}
    
    
    render() {
        
        const columns = [             
            {
              field: "username",
              headerName: "User",
              width: 200               
            },
            { field: "email", headerName: "Email", width: 200 },
            {
              field: "status",
              headerName: "Status",
              width: 120,
            },
            {
                field:"action",
                headerName: "Action",
                width: 150,
                renderCell: (params) => {
                    return(
                        <>
                        <Link to={"/user/" + params.row._id}>
                        <button className='userListEdit'>Edit</button>
                        </Link>
                        <DeleteOutline className="userListDelete"
                        onClick={() => this.handleDelete(params.row._id)}
                        />
                        </>    
                    )
                        
                }
            }      
             
             
          ];            



        
        return (
            <div className="userList">
                <h1>Users List</h1>
                <DataGrid
        rows={this.state.userRows}
        disableSelectionOnClick
        columns={columns}
        pageSize={5}
        onPageSizeChange={(newPageSize) => this.setPageSize(newPageSize)}
        rowsPerPageOptions={[5, 10, 20]}
        pagination
        getRowId={(row) => row._id}
        checkboxSelection
      />
            </div>
        );
    }
}

export default AdminUsers;