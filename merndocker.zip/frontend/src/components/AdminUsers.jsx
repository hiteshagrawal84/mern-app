import React from 'react'

class AdminUsers extends React.Component {
  
    constructor(props) {
        super()
        this.state = {
            name : props.name
        }
    }


    clickMe()
    {
       this.setState({name:this.props.name + "Ankita"})
    }
	render(){

        const {name} = this.state;
		return <React.Fragment><h1>Admin Users list {name} </h1>
        <button onClick={()=> this.clickMe()}> Click Me</button>
        </React.Fragment>
	}

}

export default AdminUsers